# GitHub Actions 自动更新配置指南

## 一、准备工作

### 1. 创建GitHub仓库
1. 访问 https://github.com/new
2. 创建新仓库(例如: `economics-papers`)
3. 设置为Public(公开)

### 2. 上传项目文件
```bash
cd /Users/pearl/Desktop/Claude_新建/经管A刊论文网站

# 初始化git
git init
git add .
git commit -m "初始提交"

# 关联远程仓库(替换为你的仓库地址)
git remote add origin https://github.com/你的用户名/economics-papers.git
git branch -M main
git push -u origin main
```

## 二、配置GitHub Pages(可选)

1. 进入仓库Settings
2. 找到Pages选项
3. Source选择: Deploy from a branch
4. Branch选择: main / (root)
5. 保存后会生成网址: `https://你的用户名.github.io/economics-papers/`

## 三、自动更新工作流程

### 工作原理
- GitHub Actions每天UTC 0点(北京时间8点)自动运行
- 运行`auto_update.py`爬虫脚本
- 抓取最新论文并更新`papers_data.json`
- 自动提交更新到仓库
- 网站自动显示最新内容

### 手动触发更新
1. 进入仓库的Actions标签
2. 选择"自动更新论文数据"工作流
3. 点击"Run workflow"按钮

## 四、验证自动更新

### 首次测试
```bash
# 本地测试爬虫
python3 auto_update.py

# 查看生成的数据
cat papers_data.json
```

### 查看运行日志
1. 进入GitHub仓库
2. 点击Actions标签
3. 查看最新的workflow运行记录

## 五、注意事项

⚠️ **重要提示**:
1. CrossRef API免费但有速率限制
2. CNKI等国内期刊需要单独实现爬虫逻辑
3. 建议添加更多期刊的RSS订阅源
4. 可以配置GitHub Secrets存储API密钥

## 六、扩展功能

### 添加更多数据源
编辑`auto_update.py`,在相应方法中添加:
- arXiv API (经济学预印本)
- SSRN API (社会科学研究网络)
- 各期刊的RSS订阅

### 配置通知
可以添加邮件或Slack通知,在更新完成后发送提醒。
