# 定时任务配置说明

## macOS/Linux 使用 crontab

1. 编辑定时任务:
```bash
crontab -e
```

2. 添加以下行(每天早上8点运行):
```
0 8 * * * cd /Users/pearl/Desktop/Claude_新建/经管A刊论文网站 && /usr/bin/python3 auto_update.py
```

## Windows 使用任务计划程序

1. 打开"任务计划程序"
2. 创建基本任务
3. 触发器:每天早上8:00
4. 操作:启动程序
   - 程序: python
   - 参数: auto_update.py
   - 起始于: /Users/pearl/Desktop/Claude_新建/经管A刊论文网站

## 手动运行测试

```bash
cd /Users/pearl/Desktop/Claude_新建/经管A刊论文网站
python3 auto_update.py
```

## 依赖安装

```bash
pip3 install requests beautifulsoup4
```
